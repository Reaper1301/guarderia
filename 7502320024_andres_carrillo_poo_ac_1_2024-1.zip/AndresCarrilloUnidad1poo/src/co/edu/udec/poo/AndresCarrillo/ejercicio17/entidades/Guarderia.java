package co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades;

import java.util.List;

public class Guarderia {
    private String nombre;
    private String direccion;
    private String telefonoContacto;
    private List<Niño> niños;
    private List<Menu> menus;
    private double costoFijoMensual;

    public Guarderia(String nombre, String direccion, String telefonoContacto, double costoFijoMensual) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefonoContacto = telefonoContacto;
        this.costoFijoMensual = costoFijoMensual;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefonoContacto() {
        return telefonoContacto;
    }

    public void setTelefonoContacto(String telefonoContacto) {
        this.telefonoContacto = telefonoContacto;
    }

    public List<Niño> getNiños() {
        return niños;
    }

    public void setNiños(List<Niño> niños) {
        this.niños = niños;
    }

    public List<Menu> getMenus() {
        return menus;
    }

    public void setMenus(List<Menu> menus) {
        this.menus = menus;
    }

    public double getCostoFijoMensual() {
        return costoFijoMensual;
    }

    public void setCostoFijoMensual(double costoFijoMensual) {
        this.costoFijoMensual = costoFijoMensual;
    }
}

package co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades;

import co.edu.ude.poo.guarderia.modelo.crud.IngredienteCrud;
import co.edu.ude.poo.guarderia.modelo.crud.PlatoCrud;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            // Crear instancias de IngredienteCrud
            IngredienteCrud ingredienteCrud = new IngredienteCrud();

            // Crear ingredientes
            Ingrediente ingrediente1 = new Ingrediente("Tomate");
            Ingrediente ingrediente2 = new Ingrediente("Queso");

            // Agregar ingredientes
            ingredienteCrud.agregar(ingrediente1);
            ingredienteCrud.agregar(ingrediente2);

            // Contar ingredientes
            System.out.println("Número de ingredientes: " + ingredienteCrud.contar());

            // Buscar ingrediente
            try {
                Ingrediente encontrado = ingredienteCrud.buscar("Tomate");
                System.out.println("Ingrediente encontrado: " + encontrado.getNombre());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Editar ingrediente
            try {
                ingrediente1.setNombre("Tomate Cherry");
                ingredienteCrud.editar(ingrediente1);
                System.out.println("Ingrediente editado: " + ingredienteCrud.buscar("Tomate Cherry").getNombre());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Eliminar ingrediente
            try {
                ingredienteCrud.eliminar("Queso");
                System.out.println("Ingrediente eliminado. Número de ingredientes: " + ingredienteCrud.contar());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Listar todos los ingredientes
            try {
                List<Ingrediente> ingredientes = ingredienteCrud.listarTodo();
                System.out.println("Lista de ingredientes:");
                for (Ingrediente ingrediente : ingredientes) {
                    System.out.println(ingrediente.getNombre());
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Crear instancias de PlatoCrud
            PlatoCrud platoCrud = new PlatoCrud();

            // Crear platos
            Plato plato1 = new Plato("Pizza", 8.50);
            plato1.agregarIngrediente(ingrediente1);
            plato1.agregarIngrediente(ingrediente2);

            Plato plato2 = new Plato("Ensalada", 5.00);
            plato2.agregarIngrediente(ingrediente1);

            // Agregar platos
            platoCrud.agregar(plato1);
            platoCrud.agregar(plato2);

            // Contar platos
            System.out.println("Número de platos: " + platoCrud.contar());

            // Buscar plato
            try {
                Plato platoEncontrado = platoCrud.buscar("Pizza");
                System.out.println("Plato encontrado: " + platoEncontrado.obtenerDetalles());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Editar plato
            try {
                plato1.setPrecio(9.00);
                platoCrud.editar(plato1);
                System.out.println("Plato editado: " + platoCrud.buscar("Pizza").obtenerDetalles());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Eliminar plato
            try {
                platoCrud.eliminar("Ensalada");
                System.out.println("Plato eliminado. Número de platos: " + platoCrud.contar());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Listar todos los platos
            try {
                List<Plato> platos = platoCrud.listarTodo();
                System.out.println("Lista de platos:");
                for (Plato plato : platos) {
                    System.out.println(plato.obtenerDetalles());
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

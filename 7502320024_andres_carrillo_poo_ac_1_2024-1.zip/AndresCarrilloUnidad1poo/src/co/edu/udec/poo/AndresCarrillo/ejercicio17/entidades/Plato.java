package co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades;

import java.util.ArrayList;
import java.util.List;

public class Plato {
    private String nombre;
    private final List<Ingradientes> ingredientes = new ArrayList<>();
    private double precio;

    public Plato(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Ingradientes> getIngredientes() {
        return ingredientes;
    }

    public void agregarIngrediente(Ingrediente ingrediente) {
        Ingradientes ingradiente = null;
        ingredientes.add(ingradiente);
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String obtenerDetalles() {
        StringBuilder detalles = new StringBuilder(nombre + " (precio: " + precio + ")\nIngredientes: ");
        for (Ingradientes ingrediente : ingredientes) {
            detalles.append(ingrediente.getNombre()).append(", ");
        }
        return detalles.toString();
    }

    private static class Ingradientes {

        public Ingradientes() {
        }

        private AbstractStringBuilder getNombre() {
            throw new UnsupportedOperationException("Not supported yet."); 
        }
    }

    private static class AbstractStringBuilder {

        public AbstractStringBuilder() {
        }
    }
}

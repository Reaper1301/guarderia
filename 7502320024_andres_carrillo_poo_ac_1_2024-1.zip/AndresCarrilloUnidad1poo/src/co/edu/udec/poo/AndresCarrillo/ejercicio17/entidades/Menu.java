package co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades;

import java.util.List;

public class Menu {
    private String idMenu;
    private List<Plato> platos;

    public Menu(String idMenu, List<Plato> platos) {
        this.idMenu = idMenu;
        this.platos = platos;
    }

    public String getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(String idMenu) {
        this.idMenu = idMenu;
    }

    public List<Plato> getPlatos() {
        return platos;
    }

    public void setPlatos(List<Plato> platos) {
        this.platos = platos;
    }
}

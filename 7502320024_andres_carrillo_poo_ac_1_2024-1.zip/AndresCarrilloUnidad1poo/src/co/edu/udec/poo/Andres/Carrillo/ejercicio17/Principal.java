package co.edu.udec.poo.Andres.Carrillo.ejercicio17;

import co.edu.ude.poo.guarderia.modelo.crud.NiñoCrud;
import co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades.Niño;
import java.util.*;

public class Principal {
    public static void main(String[] args) {
        try {
            // Crear objetos de la clase Niño
            Niño niño1 = new Niño("123", "Juan Perez", new Date(), new Date());
            Niño niño2 = new Niño("456", "Ana Gomez", new Date(), new Date());

            // Crear objeto de NiñoCrud y agregar niños
            NiñoCrud niñoCrud = new NiñoCrud();
            niñoCrud.agregar(niño1);
            niñoCrud.agregar(niño2);

            // Contar niños
            System.out.println("Número de niños: " + niñoCrud.contar());

            // Buscar y mostrar detalles de un niño
            try {
                Niño buscado = niñoCrud.buscar("123");
                System.out.println("Niño encontrado: " + buscado.getNombre());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Editar niño
            try {
                niño1.setNombre("Juan Perez Gonzalez");
                niñoCrud.editar(niño1);
                System.out.println("Niño editado: " + niñoCrud.buscar("123").getNombre());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Eliminar niño
            try {
                niñoCrud.eliminar("456");
                System.out.println("Niño eliminado. Número de niños: " + niñoCrud.contar());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            // Listar todos los niños
            try {
                List<Niño> niños = niñoCrud.listarTodo();
                System.out.println("Lista de niños:");
                for (Niño niño : niños) {
                    System.out.println(niño.getNombre());
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

          

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

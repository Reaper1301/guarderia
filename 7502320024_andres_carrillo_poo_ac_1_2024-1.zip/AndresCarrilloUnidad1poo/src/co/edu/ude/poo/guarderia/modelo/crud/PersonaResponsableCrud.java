package co.edu.ude.poo.guarderia.modelo.crud;

import co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades.PersonaResponsable;
import java.util.ArrayList;
import java.util.List;

public class PersonaResponsableCrud {
    private final List<PersonaResponsable> personasResponsables = new ArrayList<>();

    public void agregar(PersonaResponsable personaResponsable) throws Exception {
        for (PersonaResponsable p : personasResponsables) {
            if (p.getDni().equals(personaResponsable.getDni())) {
                throw new Exception("La persona responsable ya existe.");
            }
        }
        personasResponsables.add(personaResponsable);
    }

    public PersonaResponsable buscar(String dni) throws Exception {
        for (PersonaResponsable p : personasResponsables) {
            if (p.getDni().equals(dni)) {
                return p;
            }
        }
        throw new Exception("Persona responsable no encontrada.");
    }

    public void editar(PersonaResponsable personaResponsable) throws Exception {
        for (int i = 0; i < personasResponsables.size(); i++) {
            if (personasResponsables.get(i).getDni().equals(personaResponsable.getDni())) {
                personasResponsables.set(i, personaResponsable);
                return;
            }
        }
        throw new Exception("Persona responsable no encontrada.");
    }

    public void eliminar(String dni) throws Exception {
        for (int i = 0; i < personasResponsables.size(); i++) {
            if (personasResponsables.get(i).getDni().equals(dni)) {
                personasResponsables.remove(i);
                return;
            }
        }
        throw new Exception("Persona responsable no encontrada.");
    }

    public List<PersonaResponsable> listarTodo() throws Exception {
        if (personasResponsables.isEmpty()) {
            throw new Exception("No hay personas responsables en la lista.");
        }
        return personasResponsables;
    }

    public int contar() {
        return personasResponsables.size();
    }
}

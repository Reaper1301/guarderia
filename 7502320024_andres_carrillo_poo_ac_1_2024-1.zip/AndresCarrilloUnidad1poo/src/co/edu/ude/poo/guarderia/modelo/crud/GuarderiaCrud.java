package co.edu.ude.poo.guarderia.modelo.crud;

import co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades.Guarderia;
import java.util.ArrayList;
import java.util.List;

public class GuarderiaCrud {
    private List<Guarderia> guarderias = new ArrayList<>();

    public void agregar(Guarderia guarderia) throws Exception {
        for (Guarderia g : guarderias) {
            if (g.getNombre().equals(guarderia.getNombre())) {
                throw new Exception("La guardería ya existe.");
            }
        }
        guarderias.add(guarderia);
    }

    public Guarderia buscar(String nombre) throws Exception {
        for (Guarderia g : guarderias) {
            if (g.getNombre().equals(nombre)) {
                return g;
            }
        }
        throw new Exception("Guardería no encontrada.");
    }

    public void editar(Guarderia guarderia) throws Exception {
        for (int i = 0; i < guarderias.size(); i++) {
            if (guarderias.get(i).getNombre().equals(guarderia.getNombre())) {
                guarderias.set(i, guarderia);
                return;
            }
        }
        throw new Exception("Guardería no encontrada.");
    }

    public void eliminar(String nombre) throws Exception {
        for (int i = 0; i < guarderias.size(); i++) {
            if (guarderias.get(i).getNombre().equals(nombre)) {
                guarderias.remove(i);
                return;
            }
        }
        throw new Exception("Guardería no encontrada.");
    }

    public List<Guarderia> listarTodo() throws Exception {
        if (guarderias.isEmpty()) {
            throw new Exception("No hay guarderías en la lista.");
        }
        return guarderias;
    }

    public int contar() {
        return guarderias.size();
    }
}

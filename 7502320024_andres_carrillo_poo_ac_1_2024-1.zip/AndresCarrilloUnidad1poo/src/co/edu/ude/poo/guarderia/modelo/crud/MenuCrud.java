package co.edu.ude.poo.guarderia.modelo.crud;

import co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades.Menu;
import java.util.ArrayList;
import java.util.List;

public class MenuCrud {
    private List<Menu> menus = new ArrayList<>();

    public void agregar(Menu menu) throws Exception {
        for (Menu m : menus) {
            if (m.getIdMenu().equals(menu.getIdMenu())) {
                throw new Exception("El menú ya existe.");
            }
        }
        menus.add(menu);
    }

    public Menu buscar(String idMenu) throws Exception {
        for (Menu m : menus) {
            if (m.getIdMenu().equals(idMenu)) {
                return m;
            }
        }
        throw new Exception("Menú no encontrado.");
    }

    public void editar(Menu menu) throws Exception {
        for (int i = 0; i < menus.size(); i++) {
            if (menus.get(i).getIdMenu().equals(menu.getIdMenu())) {
                menus.set(i, menu);
                return;
            }
        }
        throw new Exception("Menú no encontrado.");
    }

    public void eliminar(String idMenu) throws Exception {
        for (int i = 0; i < menus.size(); i++) {
            if (menus.get(i).getIdMenu().equals(idMenu)) {
                menus.remove(i);
                return;
            }
        }
        throw new Exception("Menú no encontrado.");
    }

    public List<Menu> listarTodo() throws Exception {
        if (menus.isEmpty()) {
            throw new Exception("No hay menús en la lista.");
        }
        return menus;
    }

    public int contar() {
        return menus.size();
    }
}

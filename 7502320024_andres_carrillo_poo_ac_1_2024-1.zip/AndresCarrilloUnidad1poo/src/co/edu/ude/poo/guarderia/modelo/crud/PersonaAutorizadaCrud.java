package co.edu.ude.poo.guarderia.modelo.crud;

import java.util.ArrayList;
import java.util.List;

public class PersonaAutorizadaCrud {
    private final List<PersonaAutorizada> personasAutorizadas = new ArrayList<>();

    public void agregar(PersonaAutorizada personaAutorizada) throws Exception {
        for (PersonaAutorizada p : personasAutorizadas) {
            if (p.getDni().equals(personaAutorizada.getDni())) {
                throw new Exception("La persona autorizada ya existe.");
            }
        }
        personasAutorizadas.add(personaAutorizada);
    }

    public PersonaAutorizada buscar(String dni) throws Exception {
        for (PersonaAutorizada p : personasAutorizadas) {
            if (p.getDni().equals(dni)) {
                return p;
            }
        }
        throw new Exception("Persona autorizada no encontrada.");
    }

    public void editar(PersonaAutorizada personaAutorizada) throws Exception {
        for (int i = 0; i < personasAutorizadas.size(); i++) {
            if (personasAutorizadas.get(i).getDni().equals(personaAutorizada.getDni())) {
                personasAutorizadas.set(i, personaAutorizada);
                return;
            }
        }
        throw new Exception("Persona autorizada no encontrada.");
    }

    public void eliminar(String dni) throws Exception {
        for (int i = 0; i < personasAutorizadas.size(); i++) {
            if (personasAutorizadas.get(i).getDni().equals(dni)) {
                personasAutorizadas.remove(i);
                return;
            }
        }
        throw new Exception("Persona autorizada no encontrada.");
    }

    public List<PersonaAutorizada> listarTodo() throws Exception {
        if (personasAutorizadas.isEmpty()) {
            throw new Exception("No hay personas autorizadas en la lista.");
        }
        return personasAutorizadas;
    }

    public int contar() {
        return personasAutorizadas.size();
    }

    private static class PersonaAutorizada {

        public PersonaAutorizada() {
        }

        private Object getDni() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}

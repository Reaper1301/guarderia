package co.edu.ude.poo.guarderia.modelo.crud;

import co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades.Ingrediente;
import java.util.ArrayList;
import java.util.List;

public class IngredienteCrud {
    private final List<Ingrediente> ingredientes = new ArrayList<>();

    public void agregar(Ingrediente ingrediente) throws Exception {
        for (Ingrediente i : ingredientes) {
            if (i.getNombre().equals(ingrediente.getNombre())) {
                throw new Exception("El ingrediente ya existe.");
            }
        }
        ingredientes.add(ingrediente);
    }

    public Ingrediente buscar(String nombre) throws Exception {
        for (Ingrediente i : ingredientes) {
            if (i.getNombre().equals(nombre)) {
                return i;
            }
        }
        throw new Exception("Ingrediente no encontrado.");
    }

    public void editar(Ingrediente ingrediente) throws Exception {
        for (int i = 0; i < ingredientes.size(); i++) {
            if (ingredientes.get(i).getNombre().equals(ingrediente.getNombre())) {
                ingredientes.set(i, ingrediente);
                return;
            }
        }
        throw new Exception("Ingrediente no encontrado.");
    }

    public void eliminar(String nombre) throws Exception {
        for (int i = 0; i < ingredientes.size(); i++) {
            if (ingredientes.get(i).getNombre().equals(nombre)) {
                ingredientes.remove(i);
                return;
            }
        }
        throw new Exception("Ingrediente no encontrado.");
    }

    public List<Ingrediente> listarTodo() throws Exception {
        if (ingredientes.isEmpty()) {
            throw new Exception("No hay ingredientes en la lista.");
        }
        return ingredientes;
    }

    public int contar() {
        return ingredientes.size();
    }


}

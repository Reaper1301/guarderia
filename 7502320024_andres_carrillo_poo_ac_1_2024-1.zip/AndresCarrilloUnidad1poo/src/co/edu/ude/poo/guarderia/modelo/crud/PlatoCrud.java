package co.edu.ude.poo.guarderia.modelo.crud;

import co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades.Plato;
import java.util.ArrayList;
import java.util.List;

public class PlatoCrud {
    private List<Plato> platos = new ArrayList<>();

    public void agregar(Plato plato) throws Exception {
        for (Plato p : platos) {
            if (p.getNombre().equals(plato.getNombre())) {
                throw new Exception("El plato ya existe.");
            }
        }
        platos.add(plato);
    }

    public Plato buscar(String nombre) throws Exception {
        for (Plato p : platos) {
            if (p.getNombre().equals(nombre)) {
                return p;
            }
        }
        throw new Exception("Plato no encontrado.");
    }

    public void editar(Plato plato) throws Exception {
        for (int i = 0; i < platos.size(); i++) {
            if (platos.get(i).getNombre().equals(plato.getNombre())) {
                platos.set(i, plato);
                return;
            }
        }
        throw new Exception("Plato no encontrado.");
    }

    public void eliminar(String nombre) throws Exception {
        for (int i = 0; i < platos.size(); i++) {
            if (platos.get(i).getNombre().equals(nombre)) {
                platos.remove(i);
                return;
            }
        }
        throw new Exception("Plato no encontrado.");
    }

    public List<Plato> listarTodo() throws Exception {
        if (platos.isEmpty()) {
            throw new Exception("No hay platos en la lista.");
        }
        return platos;
    }

    public int contar() {
        return platos.size();
    }
}

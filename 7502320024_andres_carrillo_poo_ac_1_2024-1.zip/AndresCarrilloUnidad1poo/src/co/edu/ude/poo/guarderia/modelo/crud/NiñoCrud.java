package co.edu.ude.poo.guarderia.modelo.crud;

import co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades.Niño;
import java.util.ArrayList;
import java.util.List;

public class NiñoCrud {
    private List<Niño> niños = new ArrayList<>();

    public void agregar(Niño niño) throws Exception {
        for (Niño n : niños) {
            if (n.getNumeroMatricula().equals(niño.getNumeroMatricula())) {
                throw new Exception("El niño ya existe.");
            }
        }
        niños.add(niño);
    }

    public Niño buscar(String numeroMatricula) throws Exception {
        for (Niño n : niños) {
            if (n.getNumeroMatricula().equals(numeroMatricula)) {
                return n;
            }
        }
        throw new Exception("Niño no encontrado.");
    }

    public void editar(Niño niño) throws Exception {
        for (int i = 0; i < niños.size(); i++) {
            if (niños.get(i).getNumeroMatricula().equals(niño.getNumeroMatricula())) {
                niños.set(i, niño);
                return;
            }
        }
        throw new Exception("Niño no encontrado.");
    }

    public void eliminar(String numeroMatricula) throws Exception {
        for (int i = 0; i < niños.size(); i++) {
            if (niños.get(i).getNumeroMatricula().equals(numeroMatricula)) {
                niños.remove(i);
                return;
            }
        }
        throw new Exception("Niño no encontrado.");
    }

    public List<Niño> listarTodo() throws Exception {
        if (niños.isEmpty()) {
            throw new Exception("No hay niños en la lista.");
        }
        return niños;
    }

    public int contar() {
        return niños.size();
    }
}

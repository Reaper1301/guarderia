package co.edu.ude.poo.vistas.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaCrudPlato extends JDialog {

    public VentanaCrudPlato(JFrame ventanaPrincipal) {
        super(ventanaPrincipal, "Ventana CRUD Plato", true);
        
        // Configurar la ventana
        setSize(400, 300);
        setLocationRelativeTo(ventanaPrincipal);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        // Layout de la ventana
        setLayout(new BorderLayout());
        
        // Panel superior
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel lblTitulo = new JLabel("Formulario Plato");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(Color.BLUE);
        panelSuperior.add(lblTitulo);
        add(panelSuperior, BorderLayout.NORTH);
        
        // Panel izquierdo con imagen representativa
        JPanel panelIzquierdo = new JPanel();
        // Agrega la etiqueta con la imagen representativa
        add(panelIzquierdo, BorderLayout.WEST);
        
        // Panel derecho con controles de entrada
        JPanel panelDerecho = new JPanel(new GridLayout(3, 2));
        panelDerecho.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Controles de entrada
        JLabel lblCodigo = new JLabel("Código:");
        JTextField txtCodigo = new JTextField(10);
        JLabel lblNombre = new JLabel("Nombre:");
        JTextField txtNombre = new JTextField(20);
        JLabel lblDescripcion = new JLabel("Descripción:");
        JTextArea txtDescripcion = new JTextArea(4, 20);
        
        panelDerecho.add(lblCodigo);
        panelDerecho.add(txtCodigo);
        panelDerecho.add(lblNombre);
        panelDerecho.add(txtNombre);
        panelDerecho.add(lblDescripcion);
        panelDerecho.add(new JScrollPane(txtDescripcion));
        
        add(panelDerecho, BorderLayout.CENTER);
        
        // Panel inferior con botones
        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        JButton btnAgregar = new JButton("Agregar");
        JButton btnBuscar = new JButton("Buscar");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnListar = new JButton("Listar");
        
        panelInferior.add(btnAgregar);
        panelInferior.add(btnBuscar);
        panelInferior.add(btnEditar);
        panelInferior.add(btnEliminar);
        panelInferior.add(btnLimpiar);
        panelInferior.add(btnListar);
        
        add(panelInferior, BorderLayout.SOUTH);
        
        // Acciones de los botones
        btnLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Limpiar los campos del formulario
                txtCodigo.setText("");
                txtNombre.setText("");
                txtDescripcion.setText("");
            }
        });
        
      
        
        // Mostrar la ventana
        setVisible(true);
    }
    
 
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new VentanaCrudPlato(null);
            }
        });
    }
}

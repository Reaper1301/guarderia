package co.edu.ude.poo.vistas.gui;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class VentanaCrudUsuario extends JDialog {
    private JLabel tituloLabel, imagenLabel;
    private JPanel formPanel, buttonPanel;
    private JTextField nombreField, apellidoField, emailField;
    private JPasswordField passwordField;
    private JButton agregarButton, buscarButton, eliminarButton, limpiarButton, listarButton;

    private static ArrayList<Usuario> usuarios = new ArrayList<>();

    public VentanaCrudUsuario(JFrame parent) {
        super(parent, true);
        setTitle("Formulario Usuario");
        setSize(400, 300);
        setLocationRelativeTo(parent);

        // Configuración de la ventana
        setLayout(new BorderLayout());

        // Título
        tituloLabel = new JLabel("Formulario Usuario", JLabel.CENTER);
        tituloLabel.setForeground(Color.BLUE);
        tituloLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(tituloLabel, BorderLayout.NORTH);

        // Imagen representativa
        imagenLabel = new JLabel(new ImageIcon("C:/Users/Reaper/pictures/iconos guarderia/usuario.png"));
        add(imagenLabel, BorderLayout.WEST);

        // Panel de formulario
        formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(4, 2));
        formPanel.add(new JLabel("Nombre:"));
        nombreField = new JTextField();
        formPanel.add(nombreField);
        formPanel.add(new JLabel("Apellido:"));
        apellidoField = new JTextField();
        formPanel.add(apellidoField);
        formPanel.add(new JLabel("Email:"));
        emailField = new JTextField();
        formPanel.add(emailField);
        formPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        formPanel.add(passwordField);
        add(formPanel, BorderLayout.CENTER);

        // Panel de botones
        buttonPanel = new JPanel();
        agregarButton = new JButton("Agregar", new ImageIcon("C:/Users/Reaper/pictures/iconos guarderia/agregar.png"));
        buscarButton = new JButton("Buscar", new ImageIcon("C:/Users/Reaper/pictures/iconos guarderia/buscar.png"));
        eliminarButton = new JButton("Eliminar", new ImageIcon("C:/Users/Reaper/pictures/iconos guarderia/eliminar.png"));
        limpiarButton = new JButton("Limpiar", new ImageIcon("C:/Users/Reaper/pictures/iconos guarderia/limpiar.png"));
        listarButton = new JButton("Listar", new ImageIcon("C:/Users/Reaper/pictures/iconos guarderia/listar.png"));

        buttonPanel.add(agregarButton);
        buttonPanel.add(buscarButton);
        buttonPanel.add(eliminarButton);
        buttonPanel.add(limpiarButton);
        buttonPanel.add(listarButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Agregar ActionListeners a los botones
        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarUsuario();
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarUsuario();
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarUsuario();
            }
        });

        limpiarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        listarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarUsuarios();
            }
        });

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void agregarUsuario() {
        String nombre = nombreField.getText();
        String apellido = apellidoField.getText();
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        // Validaciones de entrada
        if (nombre.isEmpty() || apellido.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validación de formato del email
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(this, "Email no válido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Confirmación de guardado
        int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro que desea guardar esta información?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            Usuario usuario = new Usuario(nombre, apellido, email, password);
            if (!usuarios.contains(usuario)) {
                usuarios.add(usuario);
                JOptionPane.showMessageDialog(this, "Usuario agregado satisfactoriamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "El usuario ya existe", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void buscarUsuario() {
        String email = emailField.getText();

        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El campo Email es obligatorio para buscar", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (Usuario usuario : usuarios) {
            if (usuario.getEmail().equals(email)) {
                nombreField.setText(usuario.getNombre());
                apellidoField.setText(usuario.getApellido());
                passwordField.setText(usuario.getPassword());
                eliminarButton.setEnabled(true);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Usuario no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
        eliminarButton.setEnabled(false);
    }

    private void eliminarUsuario() {
        String email = emailField.getText();

        int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro que desea eliminar esta información?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            usuarios.removeIf(usuario -> usuario.getEmail().equals(email));
            JOptionPane.showMessageDialog(this, "Usuario eliminado satisfactoriamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            limpiarCampos();
        }
    }

    private void limpiarCampos() {
        nombreField.setText("");
        apellidoField.setText("");
        emailField.setText("");
        passwordField.setText("");
        eliminarButton.setEnabled(false);
    }

    private void listarUsuarios() {
        // Aquí se cerraría la ventana actual y se mostraría la VentanaReporteUsuario
        dispose();
        new VentanaReporteUsuario(this, usuarios).setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaCrudUsuario(null).setVisible(true));
    }

    private static class Usuario {

        public Usuario() {
        }

        private Usuario(String nombre, String apellido, String email, String password) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        private Object getEmail() {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        private String getNombre() {
            throw new UnsupportedOperationException("Not supported yet."); 
        }

        private String getApellido() {
            throw new UnsupportedOperationException("Not supported yet."); 
        }

        private String getPassword() {
            throw new UnsupportedOperationException("Not supported yet."); 
        }
    }

    private static class VentanaReporteUsuario {

        public VentanaReporteUsuario(VentanaCrudUsuario aThis, ArrayList<Usuario> usuarios) {
        }

        private void setVisible(boolean b) {
            throw new UnsupportedOperationException("Not supported yet."); 
        }
    }
}

package co.edu.ude.poo.persistencia;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Serializacion {

    public static void main(String[] args) {
        // Crear algunos objetos de ejemplo
        Guarderia guarderia = new Guarderia("Guardería ABC", "Calle Principal 123");
        Ingrediente ingrediente = new Ingrediente("Harina", 500);
        Menu menu = new Menu("Menú del Día", "Incluye entrada, plato principal y postre");
        Niño niño = new Niño("Juan", 5);
        PersonaAutorizada autorizada = new PersonaAutorizada("María", "123456789");
        PersonaResponsable responsable = new PersonaResponsable("Pedro", "Padre");
        Plato plato = new Plato("Pizza", "Pizza casera con ingredientes frescos");

        // Lista para almacenar los objetos
        List<Object> objetos = new ArrayList<>();
        objetos.add(guarderia);
        objetos.add(ingrediente);
        objetos.add(menu);
        objetos.add(niño);
        objetos.add(autorizada);
        objetos.add(responsable);
        objetos.add(plato);

        // Serializar los objetos
        serializarObjetos(objetos, "datos.obj");

        // Deserializar los objetos
        List<Object> objetosDeserializados = deserializarObjetos("datos.obj");
        for (Object obj : objetosDeserializados) {
            System.out.println(obj);
        }
    }

    // Método para serializar objetos en un archivo
    public static void serializarObjetos(List<Object> objetos, String archivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(objetos);
            System.out.println("Objetos serializados correctamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método para deserializar objetos desde un archivo
    public static List<Object> deserializarObjetos(String archivo) {
        List<Object> objetos = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            objetos = (List<Object>) ois.readObject();
            System.out.println("Objetos deserializados correctamente.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return objetos;
    }

    // Clase Guarderia
    static class Guarderia implements Serializable {
        private String nombre;
        private String direccion;

        public Guarderia(String nombre, String direccion) {
            this.nombre = nombre;
            this.direccion = direccion;
        }

        @Override
        public String toString() {
            return "Guarderia{" +
                    "nombre='" + nombre + '\'' +
                    ", direccion='" + direccion + '\'' +
                    '}';
        }
    }

    // Clase Ingrediente
    static class Ingrediente implements Serializable {
        private String nombre;
        private int cantidad;

        public Ingrediente(String nombre, int cantidad) {
            this.nombre = nombre;
            this.cantidad = cantidad;
        }

        @Override
        public String toString() {
            return "Ingrediente{" +
                    "nombre='" + nombre + '\'' +
                    ", cantidad=" + cantidad +
                    '}';
        }
    }

    // Clase Menu
    static class Menu implements Serializable {
        private String nombre;
        private String descripcion;

        public Menu(String nombre, String descripcion) {
            this.nombre = nombre;
            this.descripcion = descripcion;
        }

        @Override
        public String toString() {
            return "Menu{" +
                    "nombre='" + nombre + '\'' +
                    ", descripcion='" + descripcion + '\'' +
                    '}';
        }
    }

    // Clase Niño
    static class Niño implements Serializable {
        private String nombre;
        private int edad;

        public Niño(String nombre, int edad) {
            this.nombre = nombre;
            this.edad = edad;
        }

        @Override
        public String toString() {
            return "Niño{" +
                    "nombre='" + nombre + '\'' +
                    ", edad=" + edad +
                    '}';
        }
    }

    // Clase PersonaAutorizada
    static class PersonaAutorizada implements Serializable {
        private String nombre;
        private String documentoIdentidad;

        public PersonaAutorizada(String nombre, String documentoIdentidad) {
            this.nombre = nombre;
            this.documentoIdentidad = documentoIdentidad;
        }

        @Override
        public String toString() {
            return "PersonaAutorizada{" +
                    "nombre='" + nombre + '\'' +
                    ", documentoIdentidad='" + documentoIdentidad + '\'' +
                    '}';
        }
    }

    // Clase PersonaResponsable
    static class PersonaResponsable implements Serializable {
        private String nombre;
        private String parentesco;

        public PersonaResponsable(String nombre, String parentesco) {
            this.nombre = nombre;
            this.parentesco = parentesco;
        }

        @Override
        public String toString() {
            return "PersonaResponsable{" +
                    "nombre='" + nombre + '\'' +
                    ", parentesco='" + parentesco + '\'' +
                    '}';
        }
    }

    // Clase Plato
    static class Plato implements Serializable {
        private String nombre;
        private String descripcion;

        public Plato(String nombre, String descripcion) {
            this.nombre = nombre;
            this.descripcion = descripcion;
        }

        @Override
        public String toString() {
            return "Plato{" +
                    "nombre='" + nombre + '\'' +
                    ", descripcion='" + descripcion + '\'' +
                    '}';
        }
    }
}

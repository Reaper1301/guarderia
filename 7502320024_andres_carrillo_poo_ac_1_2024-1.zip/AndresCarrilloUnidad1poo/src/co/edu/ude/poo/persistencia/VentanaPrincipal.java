package co.edu.ude.poo.persistencia;



import co.edu.ude.poo.vistas.gui.VentanaCrudUsuario;
import co.edu.udec.poo.AndresCarrillo.ejercicio17.entidades.Plato;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class VentanaPrincipal extends JFrame {
    private JMenuBar barraDeMenu;
    private JMenu menuUsuario;
    private JMenuItem itemAgregarUsuario, itemBuscarUsuario, itemEditarUsuario, itemEliminarUsuario, itemLoginUsuario, itemRecordarClaveUsuario, itemCambiarClaveUsuario, itemSalirUsuario;

    public VentanaPrincipal() {
        setTitle("Ventana Principal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximiza la ventana al inicio
        setIconImage(new ImageIcon("C:/ruta/completa/a/icono/aplicacion.png").getImage());

        // Crear barra de menú
        barraDeMenu = new JMenuBar();

        // Crear menú Usuario
        menuUsuario = new JMenu("Usuario");
        itemAgregarUsuario = new JMenuItem("Agregar...");
        itemBuscarUsuario = new JMenuItem("Buscar...");
        itemEditarUsuario = new JMenuItem("Modificar...");
        itemEliminarUsuario = new JMenuItem("Eliminar...");
        itemLoginUsuario = new JMenuItem("Iniciar sesión...");
        itemRecordarClaveUsuario = new JMenuItem("Recordar contraseña...");
        itemCambiarClaveUsuario = new JMenuItem("Cambiar clave...");
        itemSalirUsuario = new JMenuItem("Salir...");

        // Agregar ítems al menú Usuario
        menuUsuario.add(itemAgregarUsuario);
        menuUsuario.add(itemBuscarUsuario);
        menuUsuario.add(itemEditarUsuario);
        menuUsuario.add(itemEliminarUsuario);
        menuUsuario.add(new JSeparator());
        menuUsuario.add(itemLoginUsuario);
        menuUsuario.add(itemRecordarClaveUsuario);
        menuUsuario.add(itemCambiarClaveUsuario);
        menuUsuario.add(itemSalirUsuario);

        // Agregar menú Usuario a la barra de menú
        barraDeMenu.add(menuUsuario);

        // Configurar la barra de menú en la ventana principal
        setJMenuBar(barraDeMenu);

        // Fondo de la ventana principal
        JPanel fondoPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image imagen = new ImageIcon("C:/ruta/completa/a/imagen/fondo.png").getImage();
                g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            }
        };
        setContentPane(fondoPanel);
        fondoPanel.setLayout(new BorderLayout());

        // Action Listeners para los ítems del menú Usuario
        itemAgregarUsuario.addActionListener(e -> {
            VentanaCrudUsuario ventanaCrudUsuario = new VentanaCrudUsuario(VentanaPrincipal.this);
            ventanaCrudUsuario.setVisible(true);
        });

        // Otras acciones para los ítems del menú (similares a itemAgregarUsuario)

        itemSalirUsuario.addActionListener(e -> System.exit(0));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}

class GestorPersistencia {
    private static final String ARCHIVO_GUARDERIAS = "guarderias.csv";
    private static final String ARCHIVO_INGREDIENTES = "ingredientes.csv";
    private static final String ARCHIVO_MENUS = "menus.csv";
    private static final String ARCHIVO_niños = "niños.csv";
    private static final String ARCHIVO_platos = "platos.csv";        
    private static final String ARCHIVO_personaReaponsable = "personaReaponsable.csv";
    private static final String ARCHIVO_personaAutorizada = "personaAutorizada.csv";        
   
            
// Métodos para Guarderías
    public static void guardarGuarderias(List<Guarderia> guarderias) {
        try (FileWriter writer = new FileWriter(ARCHIVO_GUARDERIAS)) {
            for (Guarderia guarderia : guarderias) {
                writer.write(guarderia.toStringCSV() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Guarderia> cargarGuarderias() {
        List<Guarderia> guarderias = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_GUARDERIAS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                Guarderia guarderia = Guarderia.parseFromCSV(linea);
                if (guarderia != null) {
                    guarderias.add(guarderia);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return guarderias;
    }

  class Ingrediente {
    private String nombre;
    private int cantidad;

    public Ingrediente(String nombre, int cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "Ingrediente{" +
                "nombre='" + nombre + '\'' +
                ", cantidad=" + cantidad +
                '}';
    }
}

class Menu {
    private String nombre;
    private String descripcion;

    public Menu(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Menu{" +
                "nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }
}

class Niño {
    private String nombre;
    private int edad;

    public Niño(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Niño{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                '}';
    }
}

class PersonaAutorizada {
    private String nombre;
    private String documentoIdentidad;

    public PersonaAutorizada(String nombre, String documentoIdentidad) {
        this.nombre = nombre;
        this.documentoIdentidad = documentoIdentidad;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDocumentoIdentidad() {
        return documentoIdentidad;
    }

    public void setDocumentoIdentidad(String documentoIdentidad) {
        this.documentoIdentidad = documentoIdentidad;
    }

    @Override
    public String toString() {
        return "PersonaAutorizada{" +
                "nombre='" + nombre + '\'' +
                ", documentoIdentidad='" + documentoIdentidad + '\'' +
                '}';
    }
}

class PersonaResponsable {
    private String nombre;
    private String parentesco;

    public PersonaResponsable(String nombre, String parentesco) {
        this.nombre = nombre;
        this.parentesco = parentesco;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }

    @Override
    public String toString() {
        return "PersonaResponsable{" +
                "nombre='" + nombre + '\'' +
                ", parentesco='" + parentesco + '\'' +
                '}';
    }
}

class Plato {
    private String nombre;
    private String descripcion;

    public Plato(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Plato{" +
                "nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }
}

}

class Guarderia {
    private String nombre;
    private String direccion;
    // Otros atributos y métodos

    public Guarderia(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String toStringCSV() {
        return nombre + "," + direccion;
    }

    public static Guarderia parseFromCSV(String linea) {
        String[] partes = linea.split(",");
        if (partes.length != 2) {
            return null;
        }
        return new Guarderia(partes[0], partes[1]);
    }
}

class Ingrediente {
    private String nombre;
    private double cantidad;
    // Otros atributos y métodos

    public Ingrediente(String nombre, double cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public String toStringCSV() {
        return nombre + "," + cantidad;
    }

    public static Ingrediente parseFromCSV(String linea) {
        String[] partes = linea.split(",");
        if (partes.length != 2) {
            return null;
        }
        return new Ingrediente(partes[0], Double.parseDouble(partes[1]));
    }
}

class Menu {
    private String nombre;
    private List<Plato> platos;
    // Otros atributos y métodos

    public Menu(String nombre, List<Plato> platos) {
        this.nombre = nombre;
        this.platos = platos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Plato> getPlatos() {
        return platos;
    }

    public void setPlatos(List<Plato> platos) {
        this.platos = platos;
    }

    public String toStringCSV() {
        StringBuilder sb = new StringBuilder();
        sb.append(nombre).append(",");
        for (Plato plato : platos) {
            sb.append(plato.getNombre()).append(":").append(plato.getPrecio()).append(";");
        }
        return sb.toString();
    }

    public static Menu parseFromCSV(String linea) {
        String[] partes = linea.split(",");
        if (partes.length != 2) {
            return null;
        }
        String nombre = partes[0];
        String[] platos = partes[1].split(";");
        List<Plato> listaPlatos = new ArrayList<>();
        for (String plato : platos) {
            String[] datosPlato = plato.split(":");
            if (datosPlato.length == 2) {
                listaPlatos.add(new Plato(datosPlato[0], Double.parseDouble(datosPlato[1])));
            }
        }
        return new Menu(nombre, listaPlatos);
    }
}

class Niño {
    private String nombre;
    private int edad;
    // Otros atributos y métodos

    public Niño(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String toStringCSV() {
        return nombre + "," + edad;
    }

    public static Niño parseFromCSV(String linea) {
        String[] partes = linea.split(",");
        if (partes.length != 2) {
            return null;
        }
        return new Niño(partes[0], Integer.parseInt(partes[1]));
    }
}

class PersonaAutorizada {
    private String nombre;
    private String parentesco;
    // Otros atributos y métodos

    public PersonaAutorizada(String nombre, String parentesco) {
        this.nombre = nombre;
        this.parentesco = parentesco;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }

    public String toStringCSV() {
        return nombre + "," + parentesco;
    }

    public static PersonaAutorizada parseFromCSV(String linea) {
        String[] partes = linea.split(",");
        if (partes.length != 2) {
            return null;
        }
        return new PersonaAutorizada(partes[0], partes[1]);
    }
}

class PersonaResponsable {
    private String nombre;
    private String telefono;
    // Otros atributos y métodos

    public PersonaResponsable(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String toStringCSV() {
        return nombre + "," + telefono;
    }

    public static PersonaResponsable parseFromCSV(String linea) {
        String[] partes = linea.split(",");
        if (partes.length != 2) {
            return null;
        }
        return new PersonaResponsable(partes[0], partes[1]);
    }
}


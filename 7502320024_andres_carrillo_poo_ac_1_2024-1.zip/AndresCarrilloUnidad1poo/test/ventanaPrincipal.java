

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ventanaPrincipal extends JFrame {
    private JMenuBar barraDeMenu;
    private JMenu menuNiño, menuPersonaAutorizada, menuPersonaResponsable, menuMenu, menuGuarderia, menuUsuario;
    private JMenuItem itemAgregarNiño, itemBuscarNiño, itemEditarNiño, itemEliminarNiño, itemBuscarPorXNiño, itemBuscarPorYNiño;
    private JMenuItem itemAgregarPersonaAutorizada, itemBuscarPersonaAutorizada, itemEditarPersonaAutorizada, itemEliminarPersonaAutorizada, itemBuscarPorXPersonaAutorizada, itemBuscarPorYPersonaAutorizada;
    private JMenuItem itemAgregarPersonaResponsable, itemBuscarPersonaResponsable, itemEditarPersonaResponsable, itemEliminarPersonaResponsable, itemBuscarPorXPersonaResponsable, itemBuscarPorYPersonaResponsable;
    private JMenuItem itemAgregarMenu, itemBuscarMenu, itemEditarMenu, itemEliminarMenu, itemBuscarPorXMenu, itemBuscarPorYMenu;
    private JMenuItem itemAgregarGuarderia, itemBuscarGuarderia, itemEditarGuarderia, itemEliminarGuarderia, itemBuscarPorXGuarderia, itemBuscarPorYGuarderia;
    private JMenuItem itemAgregarUsuario, itemBuscarUsuario, itemEditarUsuario, itemEliminarUsuario, itemLoginUsuario, itemRecordarClaveUsuario, itemCambiarClaveUsuario, itemSalirUsuario;

    public ventanaPrincipal() {
        // Configurar la ventana principal
        setTitle("Ventana Principal");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        // Establecer icono
        setIconImage(new ImageIcon("C:/Users/Reaper/pictures/iconos guarderia/ventanaPrincioal.png").getImage());

        // Crear la barra de menú
        barraDeMenu = new JMenuBar();

        // Crear menús y sus ítems
        crearMenuNiño();
        crearMenuPersonaAutorizada();
        crearMenuPersonaResponsable();
        crearMenuMenu();
        crearMenuGuarderia();
        crearMenuUsuario();

        // Agregar los menús a la barra de menú
        barraDeMenu.add(menuNiño);
        barraDeMenu.add(menuPersonaAutorizada);
        barraDeMenu.add(menuPersonaResponsable);
        barraDeMenu.add(menuMenu);
        barraDeMenu.add(menuGuarderia);
        barraDeMenu.add(menuUsuario);

        // Establecer la barra de menú en la ventana
        setJMenuBar(barraDeMenu);

        // Establecer fondo de la ventana
        setContentPane(new FondoPanel());

        // Mostrar la ventana
        setVisible(true);
    }

    private void crearMenuNiño() {
        menuNiño = new JMenu("Niño");
        itemAgregarNiño = new JMenuItem("Agregar...");
        itemBuscarNiño = new JMenuItem("Buscar...");
        itemEditarNiño = new JMenuItem("Modificar...");
        itemEliminarNiño = new JMenuItem("Eliminar...");
        JMenu subMenuReportesNiño = new JMenu("Reportes...");
        itemBuscarPorXNiño = new JMenuItem("Buscar por");
        itemBuscarPorYNiño = new JMenuItem("Buscar por");

        subMenuReportesNiño.add(itemBuscarPorXNiño);
        subMenuReportesNiño.add(itemBuscarPorYNiño);

        menuNiño.add(itemAgregarNiño);
        menuNiño.add(itemBuscarNiño);
        menuNiño.add(itemEditarNiño);
        menuNiño.add(itemEliminarNiño);
        menuNiño.addSeparator();
        menuNiño.add(subMenuReportesNiño);
    }

    private void crearMenuPersonaAutorizada() {
        menuPersonaAutorizada = new JMenu("PersonaAutorizada");
        itemAgregarPersonaAutorizada = new JMenuItem("Agregar...");
        itemBuscarPersonaAutorizada = new JMenuItem("Buscar...");
        itemEditarPersonaAutorizada = new JMenuItem("Modificar...");
        itemEliminarPersonaAutorizada = new JMenuItem("Eliminar...");
        JMenu subMenuReportesPersonaAutorizada = new JMenu("Reportes...");
        itemBuscarPorXPersonaAutorizada = new JMenuItem("Buscar por");
        itemBuscarPorYPersonaAutorizada = new JMenuItem("Buscar por");

        subMenuReportesPersonaAutorizada.add(itemBuscarPorXPersonaAutorizada);
        subMenuReportesPersonaAutorizada.add(itemBuscarPorYPersonaAutorizada);

        menuPersonaAutorizada.add(itemAgregarPersonaAutorizada);
        menuPersonaAutorizada.add(itemBuscarPersonaAutorizada);
        menuPersonaAutorizada.add(itemEditarPersonaAutorizada);
        menuPersonaAutorizada.add(itemEliminarPersonaAutorizada);
        menuPersonaAutorizada.addSeparator();
        menuPersonaAutorizada.add(subMenuReportesPersonaAutorizada);
    }

    private void crearMenuPersonaResponsable() {
        menuPersonaResponsable = new JMenu("PersonaResponsable");
        itemAgregarPersonaResponsable = new JMenuItem("Agregar...");
        itemBuscarPersonaResponsable = new JMenuItem("Buscar...");
        itemEditarPersonaResponsable = new JMenuItem("Modificar...");
        itemEliminarPersonaResponsable = new JMenuItem("Eliminar...");
        JMenu subMenuReportesPersonaResponsable = new JMenu("Reportes...");
        itemBuscarPorXPersonaResponsable = new JMenuItem("Buscar");
        itemBuscarPorYPersonaResponsable = new JMenuItem("Buscar");

        subMenuReportesPersonaResponsable.add(itemBuscarPorXPersonaResponsable);
        subMenuReportesPersonaResponsable.add(itemBuscarPorYPersonaResponsable);

        menuPersonaResponsable.add(itemAgregarPersonaResponsable);
        menuPersonaResponsable.add(itemBuscarPersonaResponsable);
        menuPersonaResponsable.add(itemEditarPersonaResponsable);
        menuPersonaResponsable.add(itemEliminarPersonaResponsable);
        menuPersonaResponsable.addSeparator();
        menuPersonaResponsable.add(subMenuReportesPersonaResponsable);
    }

    private void crearMenuMenu() {
        menuMenu = new JMenu("Menu");
        itemAgregarMenu = new JMenuItem("Agregar...");
        itemBuscarMenu = new JMenuItem("Buscar...");
        itemEditarMenu = new JMenuItem("Modificar...");
        itemEliminarMenu = new JMenuItem("Eliminar...");
        JMenu subMenuReportesMenu = new JMenu("Reportes...");
        itemBuscarPorXMenu = new JMenuItem("Buscar");
        itemBuscarPorYMenu = new JMenuItem("Buscar por");

        subMenuReportesMenu.add(itemBuscarPorXMenu);
        subMenuReportesMenu.add(itemBuscarPorYMenu);

        menuMenu.add(itemAgregarMenu);
        menuMenu.add(itemBuscarMenu);
        menuMenu.add(itemEditarMenu);
        menuMenu.add(itemEliminarMenu);
        menuMenu.addSeparator();
        menuMenu.add(subMenuReportesMenu);
    }

    private void crearMenuGuarderia() {
        menuGuarderia = new JMenu("Guardería");
        itemAgregarGuarderia = new JMenuItem("Agregar...");
        itemBuscarGuarderia = new JMenuItem("Buscar...");
        itemEditarGuarderia = new JMenuItem("Modificar...");
        itemEliminarGuarderia = new JMenuItem("Eliminar...");
        JMenu subMenuReportesGuarderia = new JMenu("Reportes...");
        itemBuscarPorXGuarderia = new JMenuItem("Buscar por");
        itemBuscarPorYGuarderia = new JMenuItem("Buscar por");

        subMenuReportesGuarderia.add(itemBuscarPorXGuarderia);
        subMenuReportesGuarderia.add(itemBuscarPorYGuarderia);

        menuGuarderia.add(itemAgregarGuarderia);
        menuGuarderia.add(itemBuscarGuarderia);
        menuGuarderia.add(itemEditarGuarderia);
        menuGuarderia.add(itemEliminarGuarderia);
        menuGuarderia.addSeparator();
        menuGuarderia.add(subMenuReportesGuarderia);
    }

    private void crearMenuUsuario() {
        menuUsuario = new JMenu("Usuario");
        itemAgregarUsuario = new JMenuItem("Agregar...");
        itemBuscarUsuario = new JMenuItem("Buscar...");
        itemEditarUsuario = new JMenuItem("Modificar...");
        itemEliminarUsuario = new JMenuItem("Eliminar...");
        JMenu subMenuReportesUsuario = new JMenu("Reportes...");
        JMenuItem itemBuscarPorXUsuario = new JMenuItem("Buscar por");
        JMenuItem itemBuscarPorYUsuario = new JMenuItem("Buscar por");
        itemLoginUsuario = new JMenuItem("Iniciar sesión...");
        itemRecordarClaveUsuario = new JMenuItem("Recordar password...");
        itemCambiarClaveUsuario = new JMenuItem("Cambiar Clave...");
        itemSalirUsuario = new JMenuItem("Salir...");

        subMenuReportesUsuario.add(itemBuscarPorXUsuario);
        subMenuReportesUsuario.add(itemBuscarPorYUsuario);

        menuUsuario.add(itemAgregarUsuario);
        menuUsuario.add(itemBuscarUsuario);
        menuUsuario.add(itemEditarUsuario);
        menuUsuario.add(itemEliminarUsuario);
        menuUsuario.addSeparator();
        menuUsuario.add(subMenuReportesUsuario);
        menuUsuario.addSeparator();
        menuUsuario.add(itemLoginUsuario);
        menuUsuario.add(itemRecordarClaveUsuario);
        menuUsuario.add(itemCambiarClaveUsuario);
        menuUsuario.add(itemSalirUsuario);
    }

    // Clase interna para establecer el fondo de la ventana
    class FondoPanel extends JPanel {
        private Image imagen;

        @Override
        public void paint(Graphics g) {
            imagen = new ImageIcon("C:/Users/Reaper/pictures/iconos guarderia/fondo.jpg").getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ventanaPrincipal());
    }
}
    }
